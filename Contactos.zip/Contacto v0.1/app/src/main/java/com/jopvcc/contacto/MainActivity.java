package com.jopvcc.contacto;

import android.app.DatePickerDialog;
import android.app.Dialog;
import android.content.Intent;
import android.os.Build;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.TextView;
import java.util.Calendar;

public class MainActivity extends AppCompatActivity {
    String nombre, email, descripcion, telefono;

    //Variable para la fecha
    TextView fFecha;
    static final int DIALOG_ID = 0;
    DatePickerDialog.OnDateSetListener dialog;
    int dia, mes, anno, day, month, year;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Creando la fecha
        Calendar calendario= Calendar.getInstance();
        dia = calendario.get(Calendar.DAY_OF_MONTH);
        mes = calendario.get(Calendar.MONTH);
        anno = calendario.get(Calendar.YEAR);

        fFecha = (TextView) findViewById(R.id.textViewFecha);

        dialog = new DatePickerDialog.OnDateSetListener() {
            @Override
            public void onDateSet(DatePicker view, int year, int monthOfYear, int dayOfMonth) {
                dia = dayOfMonth;
                mes= monthOfYear+1;
                anno = year;
                mostrarFecha();
            }
        };


        //Aqui se le da vida al boton Siguiente

        Button bSig = (Button)findViewById(R.id.botonSig);
        bSig.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                EditText fNombre = (EditText)findViewById(R.id.formTextNomb);
                nombre = fNombre.getText().toString();

                EditText fTelefono = (EditText)findViewById(R.id.formTextNum);
                telefono = fTelefono.getText().toString();

                EditText fEmail = (EditText)findViewById(R.id.formTextEmail);
                email = fEmail.getText().toString();

                EditText fDescripcion = (EditText)findViewById(R.id.formTextDCont);
                descripcion = fDescripcion.getText().toString();

                //Validando campos vacios
                if (nombre.isEmpty() || telefono.isEmpty() || email.isEmpty() || descripcion.isEmpty()){
                    Snackbar.make(v, "Asegurate que no dejes campos vacios.", Snackbar.LENGTH_SHORT).show();
                }else {

                    //Fecha
                    // Check if we're running on Android 5.0 or higher
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                        String fecha = fFecha.getText().toString();
                        String[] picotillo = fecha.split("/");
                        try {
                            day = Integer.parseInt(picotillo[0]);
                            month = Integer.parseInt(picotillo[1]);
                            year = Integer.parseInt(picotillo[2]);
                        } catch (Exception e) {
                            day = dia;
                            month = mes;
                            year = anno;
                        }
                    } else {
                        DatePicker datePicker = (DatePicker) findViewById(R.id.datePicker);
                        day = datePicker.getDayOfMonth();
                        month = datePicker.getMonth() + 1;
                        year = datePicker.getYear();
                    }

                    //Creando el Intent para enviar todos los datos a la otra Interfaz
                    Intent intent = new Intent(MainActivity.this, EditContactActivity.class);
                    intent.putExtra(getResources().getString(R.string.ptnomb), nombre);
                    intent.putExtra(getResources().getString(R.string.pttelef), telefono);
                    intent.putExtra(getResources().getString(R.string.ptemail), email);
                    intent.putExtra(getResources().getString(R.string.ptdesc), descripcion);
                    intent.putExtra(getResources().getString(R.string.ptanno), anno);
                    intent.putExtra(getResources().getString(R.string.ptmes), mes);
                    intent.putExtra(getResources().getString(R.string.ptdia), dia);

                    startActivity(intent);

                }
            }
        });
    }

    //Metodos auxiliares para la fecha

    public void mostrarFecha(){
        fFecha.setText(dia + "/" + mes + "/" + anno );
    }

    @Override
    protected Dialog onCreateDialog(int id) {
        switch (id){
            case 0:
                DatePickerDialog dpDialog=new DatePickerDialog(this, dialog, anno, mes, dia);
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                    DatePicker dpPicker=dpDialog.getDatePicker();
                    dpPicker.setSpinnersShown(true);
                    dpPicker.setCalendarViewShown(false);
                    dpDialog.setView(dpPicker);
                }


                return dpDialog;
        }
        return null;
    }

    public void mostrarPicker(View control){
        showDialog(DIALOG_ID);
    }
}
