package com.jopvcc.contacto;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class EditContactActivity extends AppCompatActivity {

    private    String nombre, email, descripcion, telefono;
    private    int dia, mes, anno;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit_contact);

        //Aqui se recive todos los datos que se envian de la clase MainActivity
        Bundle datos = getIntent().getExtras();

        nombre = datos.getString(getResources().getString(R.string.ptnomb));
        telefono = datos.getString(getResources().getString(R.string.pttelef));
        email = datos.getString(getResources().getString(R.string.ptemail));
        descripcion = datos.getString(getResources().getString(R.string.ptdesc));
        dia = datos.getInt(getResources().getString(R.string.ptdia));
        mes = datos.getInt(getResources().getString(R.string.ptmes));
        anno = datos.getInt(getResources().getString(R.string.ptanno));

        //Aqui es donde se muestran todos los datos en la pantalla
        TextView mNombre = (TextView)findViewById(R.id.textViewNombre);
        TextView mFecha = (TextView)findViewById(R.id.textViewFecha);
        TextView mTelefono = (TextView) findViewById(R.id.textViewTelef);
        TextView mEmail = (TextView) findViewById(R.id.textViewEmail);
        TextView mDescripcion = (TextView) findViewById(R.id.textViewDescrp);

        mNombre.setText("Nombre y apellidos: " + nombre);
        mFecha.setText("Fecha de nacimiento: " + String.format("%d/%d/%d", dia, mes, anno));
        mTelefono.setText("Telefono: " + telefono);
        mEmail.setText("Direccion email: " + email);
        mDescripcion.setText("Descripcion: \n" + descripcion);


        //Presionar el boton Edit
        Button bEdit = (Button)findViewById(R.id.botonEdit);
        bEdit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
    }

    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        if (keyCode == KeyEvent.KEYCODE_BACK){
            finish();
        }
        return super.onKeyDown(keyCode, event);
    }
}
